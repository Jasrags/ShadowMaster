package v5

// Helper functions for pointer types
func intPtr(i int) *int          { return &i }
func stringPtr(s string) *string { return &s }

// DataLifestyleCategories contains lifestyle categories
var DataLifestyleCategories = []string{
	"Entertainment - Asset",
	"Entertainment - Service",
	"Entertainment - Outing",
	"Positive",
	"Negative",
	"Contracts",
}

// DataLifestyles contains lifestyle records keyed by their ID (lowercase with underscores)
var DataLifestyles = map[string]Lifestyle{
	"id_error_re_add_life_style_to_fix": {
		ID:         "00000000-0000-0000-0000-000000000000",
		Name:       "ID ERROR. Re-add life style to fix",
		Cost:       "1",
		Dice:       "1",
		LP:         "0",
		Multiplier: "0",
		Source:     "SR5",
		Page:       "1",
		Hide:       stringPtr(""),
	},
	"street": {
		ID:         "559653df-a9af-44e2-9e04-3044c1d1b421",
		Name:       "Street",
		Cost:       "0",
		Dice:       "1",
		LP:         "2",
		Multiplier: "20",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
		CostForArea:     intPtr(50),
		CostForComforts: intPtr(50),
		CostForSecurity: intPtr(50),
	},
	"squatter": {
		ID:         "9367556e-f82f-4f9d-840e-24c8f824ca68",
		Name:       "Squatter",
		Cost:       "500",
		Dice:       "2",
		LP:         "2",
		Multiplier: "40",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"low": {
		ID:         "451eef87-d18e-4bee-a972-1ee165b08522",
		Name:       "Low",
		Cost:       "2000",
		Dice:       "3",
		LP:         "3",
		Multiplier: "60",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"medium": {
		ID:         "9cb0222c-14c1-4bea-bf83-055513a1f33e",
		Name:       "Medium",
		Cost:       "5000",
		Dice:       "4",
		LP:         "4",
		Multiplier: "100",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"high": {
		ID:         "4a37d519-c9be-4ecc-97bb-e9d78708c374",
		Name:       "High",
		Cost:       "10000",
		Dice:       "5",
		LP:         "6",
		Multiplier: "500",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Global Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"luxury": {
		ID:         "4b513ac9-9eb3-471b-931b-839a04873b84",
		Name:       "Luxury",
		Cost:       "100000",
		Dice:       "6",
		LP:         "12",
		Multiplier: "1000",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Global Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"commercial": {
		ID:         "b7b15c35-596d-4e00-92ee-2e999f062924",
		Name:       "Commercial",
		Cost:       "8000",
		Dice:       "4",
		LP:         "4",
		Multiplier: "100",
		Source:     "RF",
		Page:       "218",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"bolt_hole": {
		ID:         "1a231a81-4985-4b57-83cf-659ad920cfb7",
		Name:       "Bolt Hole",
		Cost:       "1000",
		Dice:       "1",
		LP:         "4",
		Multiplier: "0",
		Source:     "RF",
		Page:       "216",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
	},
	"hospitalized_basic": {
		ID:         "4be85958-af8f-4404-812f-0d8a426f01d6",
		Name:       "Hospitalized, Basic",
		Cost:       "500",
		Dice:       "0",
		LP:         "0",
		Multiplier: "0",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Global Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
		Increment: stringPtr("day"),
	},
	"hospitalized_intensive": {
		ID:         "2be1a0f7-6133-4966-be57-720ed9b927a9",
		Name:       "Hospitalized, Intensive",
		Cost:       "1000",
		Dice:       "0",
		LP:         "0",
		Multiplier: "0",
		Source:     "SR5",
		Page:       "369",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Global Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Local Grid"},
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
		Increment: stringPtr("day"),
	},
	"traveler": {
		ID:         "ed775c22-8f0c-40a0-bc6f-5dbb980cedba",
		Name:       "Traveler",
		Cost:       "3000",
		Dice:       "3",
		LP:         "2",
		Multiplier: "60",
		Source:     "RF",
		Page:       "218",
		FreeGrids: &FreeGrids{FreeGrid: []FreeGrid{
			FreeGrid{Content: "Grid Subscription", Select: "Public Grid"},
		}},
		AllowBonusLP: stringPtr("True"),
	},
}

// DataComforts contains comfort records
var DataComforts = []Comfort{
	Comfort{
		Name:    "Bolt Hole",
		Minimum: 1,
		Limit:   intPtr(2),
	},
	Comfort{
		Name:    "Street",
		Minimum: 0,
		Limit:   intPtr(1),
	},
	Comfort{
		Name:    "Squatter",
		Minimum: 1,
		Limit:   intPtr(2),
	},
	Comfort{
		Name:    "Low",
		Minimum: 2,
		Limit:   intPtr(3),
	},
	Comfort{
		Name:    "Medium",
		Minimum: 3,
		Limit:   intPtr(4),
	},
	Comfort{
		Name:    "High",
		Minimum: 4,
		Limit:   intPtr(6),
	},
	Comfort{
		Name:    "Luxury",
		Minimum: 5,
		Limit:   intPtr(8),
	},
	Comfort{
		Name:    "Commercial",
		Minimum: 3,
		Limit:   intPtr(4),
	},
	Comfort{
		Name:    "Traveler",
		Minimum: 2,
		Limit:   intPtr(4),
	},
}

// DataNeighborhoods contains neighborhood records
var DataNeighborhoods = []Neighborhood{
	Neighborhood{
		Name:    "Bolt Hole",
		Minimum: 1,
		Limit:   intPtr(4),
	},
	Neighborhood{
		Name:    "Street",
		Minimum: 0,
		Limit:   intPtr(1),
	},
	Neighborhood{
		Name:    "Squatter",
		Minimum: 1,
		Limit:   intPtr(2),
	},
	Neighborhood{
		Name:    "Low",
		Minimum: 2,
		Limit:   intPtr(3),
	},
	Neighborhood{
		Name:    "Medium",
		Minimum: 4,
		Limit:   intPtr(5),
	},
	Neighborhood{
		Name:    "High",
		Minimum: 5,
		Limit:   intPtr(6),
	},
	Neighborhood{
		Name:    "Luxury",
		Minimum: 5,
		Limit:   intPtr(7),
	},
	Neighborhood{
		Name:    "Commercial",
		Minimum: 4,
		Limit:   intPtr(6),
	},
	Neighborhood{
		Name:    "Traveler",
		Minimum: 2,
		Limit:   intPtr(4),
	},
}

// DataSecurities contains security records
var DataSecurities = []Security{
	Security{
		Name:    "Bolt Hole",
		Minimum: 1,
		Limit:   intPtr(4),
	},
	Security{
		Name:    "Street",
		Minimum: 0,
		Limit:   intPtr(1),
	},
	Security{
		Name:    "Squatter",
		Minimum: 1,
		Limit:   intPtr(2),
	},
	Security{
		Name:    "Low",
		Minimum: 2,
		Limit:   intPtr(3),
	},
	Security{
		Name:    "Medium",
		Minimum: 3,
		Limit:   intPtr(4),
	},
	Security{
		Name:    "High",
		Minimum: 4,
		Limit:   intPtr(6),
	},
	Security{
		Name:    "Luxury",
		Minimum: 5,
		Limit:   intPtr(8),
	},
	Security{
		Name:    "Commercial",
		Minimum: 3,
		Limit:   intPtr(7),
	},
	Security{
		Name:    "Traveler",
		Minimum: 2,
		Limit:   intPtr(4),
	},
}

// DataLifestyleQualities contains lifestyle quality records
// TODO: Implement full quality data generation (complex due to required/forbidden structures)
var DataLifestyleQualities = []LifestyleQuality{}

// DataCities contains city records
// TODO: Implement city data generation
var DataCities = []City{}

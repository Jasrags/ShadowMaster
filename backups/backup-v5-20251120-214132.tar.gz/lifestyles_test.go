package v5

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDataLifestyleCategories(t *testing.T) {
	assert.NotEmpty(t, DataLifestyleCategories, "DataLifestyleCategories should not be empty")
	assert.GreaterOrEqual(t, len(DataLifestyleCategories), 6, "Should have at least 6 categories")
}

func TestDataLifestyles(t *testing.T) {
	assert.NotEmpty(t, DataLifestyles, "DataLifestyles should not be empty")
	assert.GreaterOrEqual(t, len(DataLifestyles), 10, "Should have many lifestyles")
	
	// Test that required fields are present
	for key, lifestyle := range DataLifestyles {
		assert.NotEmpty(t, lifestyle.ID, "Lifestyle %s should have ID", key)
		assert.NotEmpty(t, lifestyle.Name, "Lifestyle %s should have Name", key)
		assert.NotEmpty(t, lifestyle.Cost, "Lifestyle %s should have Cost", key)
		assert.NotEmpty(t, lifestyle.Dice, "Lifestyle %s should have Dice", key)
		assert.NotEmpty(t, lifestyle.LP, "Lifestyle %s should have LP", key)
		assert.NotEmpty(t, lifestyle.Multiplier, "Lifestyle %s should have Multiplier", key)
		assert.NotEmpty(t, lifestyle.Source, "Lifestyle %s should have Source", key)
		assert.NotEmpty(t, lifestyle.Page, "Lifestyle %s should have Page", key)
	}
}

func TestDataComforts(t *testing.T) {
	assert.NotEmpty(t, DataComforts, "DataComforts should not be empty")
	assert.GreaterOrEqual(t, len(DataComforts), 9, "Should have many comforts")
	
	// Test that required fields are present
	for i, comfort := range DataComforts {
		assert.NotEmpty(t, comfort.Name, "Comfort %d should have Name", i)
		assert.GreaterOrEqual(t, comfort.Minimum, 0, "Comfort %d should have Minimum >= 0", i)
	}
}

func TestDataNeighborhoods(t *testing.T) {
	assert.NotEmpty(t, DataNeighborhoods, "DataNeighborhoods should not be empty")
	assert.GreaterOrEqual(t, len(DataNeighborhoods), 9, "Should have many neighborhoods")
	
	// Test that required fields are present
	for i, neighborhood := range DataNeighborhoods {
		assert.NotEmpty(t, neighborhood.Name, "Neighborhood %d should have Name", i)
		assert.GreaterOrEqual(t, neighborhood.Minimum, 0, "Neighborhood %d should have Minimum >= 0", i)
	}
}

func TestDataSecurities(t *testing.T) {
	assert.NotEmpty(t, DataSecurities, "DataSecurities should not be empty")
	assert.GreaterOrEqual(t, len(DataSecurities), 9, "Should have many securities")
	
	// Test that required fields are present
	for i, security := range DataSecurities {
		assert.NotEmpty(t, security.Name, "Security %d should have Name", i)
		assert.GreaterOrEqual(t, security.Minimum, 0, "Security %d should have Minimum >= 0", i)
	}
}

func TestLifestyleFreeGrids(t *testing.T) {
	// Find a lifestyle with freegrids
	var lifestyle *Lifestyle
	for i := range DataLifestyles {
		l := DataLifestyles[i]
		if l.FreeGrids != nil && len(l.FreeGrids.FreeGrid) > 0 {
			lifestyle = &l
			break
		}
	}
	
	require.NotNil(t, lifestyle, "Should have at least one lifestyle with freegrids")
	assert.NotNil(t, lifestyle.FreeGrids, "FreeGrids should not be nil")
	assert.NotEmpty(t, lifestyle.FreeGrids.FreeGrid, "FreeGrid slice should not be empty")
	
	freegrid := lifestyle.FreeGrids.FreeGrid[0]
	assert.NotEmpty(t, freegrid.Content, "FreeGrid should have Content")
	assert.NotEmpty(t, freegrid.Select, "FreeGrid should have Select")
}

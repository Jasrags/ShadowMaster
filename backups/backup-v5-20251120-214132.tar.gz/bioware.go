package v5

import "shadowmaster/pkg/shadowrun/edition/v5/common"

// Note: Chummer root element is defined in books.go (shared across XML files)

// Grade represents a bioware grade (Standard, Used, Alphaware, etc.)
// XSD: grade element with required and optional fields
type Grade struct {
	// Required fields (minOccurs="1")
	ID string `xml:"id" json:"id"` // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Name         *string `xml:"name,omitempty" json:"name,omitempty"`                 // Grade name - XSD: xs:string, minOccurs="0"
	Hide         *string `xml:"hide,omitempty" json:"hide,omitempty"`                 // Hide flag - XSD: xs:string, minOccurs="0"
	IgnoreSourceDisabled *string `xml:"ignoresourcedisabled,omitempty" json:"ignoresourcedisabled,omitempty"` // Ignore source disabled - XSD: xs:string, minOccurs="0"
	Ess          *string `xml:"ess,omitempty" json:"ess,omitempty"`                   // Essence multiplier - XSD: xs:string, minOccurs="0"
	Cost         *string `xml:"cost,omitempty" json:"cost,omitempty"`                 // Cost multiplier - XSD: xs:string, minOccurs="0"
	DeviceRating *int    `xml:"devicerating,omitempty" json:"devicerating,omitempty"` // Device rating - XSD: xs:integer, minOccurs="0"
	Avail        *string `xml:"avail,omitempty" json:"avail,omitempty"`               // Availability modifier - XSD: xs:string, minOccurs="0"
	Source       *string `xml:"source,omitempty" json:"source,omitempty"`             // Source book - XSD: xs:string, minOccurs="0"
	Page         *string `xml:"page,omitempty" json:"page,omitempty"`                 // Page number - XSD: xs:string, minOccurs="0"
}

// BiowareCategory represents a bioware category with its black market classification
// XSD: category element with blackmarket attribute (xs:string, optional) and text content (xs:string)
type BiowareCategory struct {
	Name        string `xml:",chardata" json:"name"`         // Category name
	BlackMarket string `xml:"blackmarket,attr,omitempty" json:"black_market"` // Black market classification
}

// BiowareBonus represents bonuses provided by bioware
// XSD: bonus element of type bonusTypes (from bonuses.xsd)
// This embeds BaseBonus which contains all common bonus fields
type BiowareBonus struct {
	common.BaseBonus
}

// BannedGrades represents banned grades for bioware
// XSD: bannedgrades element containing grade elements (minOccurs="0", maxOccurs="unbounded")
type BannedGrades struct {
	Grade []string `xml:"grade,omitempty" json:"grade,omitempty"` // Banned grade names - XSD: minOccurs="0", maxOccurs="unbounded"
}

// AllowSubsystems represents allowed subsystem categories
// XSD: allowsubsystems element containing category elements (minOccurs="0", maxOccurs="unbounded")
type AllowSubsystems struct {
	Category []string `xml:"category,omitempty" json:"category,omitempty"` // Allowed subsystem categories - XSD: minOccurs="0", maxOccurs="unbounded"
}

// PairInclude represents items that pair with this bioware
// XSD: includepair element containing name elements (minOccurs="0", maxOccurs="unbounded")
type PairInclude struct {
	Name []string `xml:"name,omitempty" json:"name,omitempty"` // Item names that pair with this - XSD: minOccurs="0", maxOccurs="unbounded"
}

// BiowareRequired represents requirements for bioware
// XSD: required element from conditions.xsd (complex, using interface{} for now)
type BiowareRequired struct {
	OneOf *BiowareRequiredOneOf `json:"oneof,omitempty"`
	AllOf *BiowareRequiredAllOf `json:"allof,omitempty"`
}

// BiowareRequiredOneOf represents a one-of requirement
type BiowareRequiredOneOf struct {
	Cyberware string      `json:"cyberware,omitempty"` // Required cyberware
	Bioware   interface{} `json:"bioware,omitempty"`   // Can be string or []string
	Metatype  string      `json:"metatype,omitempty"`  // Required metatype
	Quality   string      `json:"quality,omitempty"`   // Required quality
}

// BiowareRequiredAllOf represents an all-of requirement
type BiowareRequiredAllOf struct {
	Metatype string `json:"metatype,omitempty"` // Required metatype
}

// Bioware represents a piece of bioware from Shadowrun 5th Edition
// XSD: bioware element with required and optional fields
type Bioware struct {
	// Required fields (minOccurs="1")
	ID       string `xml:"id" json:"id"`             // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"
	Name     string `xml:"name" json:"name"`         // Bioware name - XSD: xs:string, minOccurs="1"
	Category string `xml:"category" json:"category"` // Category - XSD: xs:string, minOccurs="1"
	Ess      string `xml:"ess" json:"ess"`           // Essence cost - XSD: xs:string, minOccurs="1"
	Capacity string `xml:"capacity" json:"capacity"` // Capacity cost - XSD: xs:string, minOccurs="1"
	Avail    string `xml:"avail" json:"avail"`       // Availability - XSD: xs:string, minOccurs="1"
	Cost     string `xml:"cost" json:"cost"`         // Cost - XSD: xs:string, minOccurs="1"
	RequireParent string `xml:"requireparent" json:"requireparent"` // Require parent - XSD: xs:string, minOccurs="1"
	Source   string `xml:"source" json:"source"`     // Source book - XSD: xs:string, minOccurs="1"
	Page     string `xml:"page" json:"page"`         // Page number - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Limit              *string            `xml:"limit,omitempty" json:"limit,omitempty"`                           // Limit - XSD: xs:string, minOccurs="0"
	Hide               *string            `xml:"hide,omitempty" json:"hide,omitempty"`                             // Hide flag - XSD: xs:string, minOccurs="0"
	IgnoreSourceDisabled *string          `xml:"ignoresourcedisabled,omitempty" json:"ignoresourcedisabled,omitempty"` // Ignore source disabled - XSD: xs:string, minOccurs="0"
	MountsTo           *string            `xml:"mountsto,omitempty" json:"mountsto,omitempty"`                     // Mounts to - XSD: xs:string, minOccurs="0"
	ModularMount       *string            `xml:"modularmount,omitempty" json:"modularmount,omitempty"`             // Modular mount - XSD: xs:string, minOccurs="0"
	BlocksMounts       *string            `xml:"blocksmounts,omitempty" json:"blocksmounts,omitempty"`             // Blocks mounts - XSD: xs:string, minOccurs="0"
	AddToParentCapacity *string           `xml:"addtoparentcapacity,omitempty" json:"addtoparentcapacity,omitempty"` // Add to parent capacity - XSD: xs:string, minOccurs="0"
	AddToParentEss     *string            `xml:"addtoparentess,omitempty" json:"addtoparentess,omitempty"`          // Add to parent essence - XSD: xs:string, minOccurs="0"
	Rating             *string            `xml:"rating,omitempty" json:"rating,omitempty"`                         // Rating - XSD: xs:string, minOccurs="0"
	ForceGrade         *string            `xml:"forcegrade,omitempty" json:"forcegrade,omitempty"`                 // Force grade - XSD: xs:string, minOccurs="0"
	Notes              *string            `xml:"notes,omitempty" json:"notes,omitempty"`                           // Notes - XSD: xs:string, minOccurs="0"
	AddWeapon          []string           `xml:"addweapon,omitempty" json:"addweapon,omitempty"`                   // Add weapon - XSD: xs:string, minOccurs="0", maxOccurs="unbounded"
	Bonus              *BiowareBonus      `xml:"bonus,omitempty" json:"bonus,omitempty"`                           // Bonus - XSD: bonusTypes, minOccurs="0"
	Forbidden          *common.Forbidden  `xml:"forbidden,omitempty" json:"forbidden,omitempty"`                   // Forbidden - XSD: forbidden element from conditions.xsd
	BannedGrades       *BannedGrades      `xml:"bannedgrades,omitempty" json:"bannedgrades,omitempty"`             // Banned grades - XSD: minOccurs="0"
	Required           *BiowareRequired   `xml:"required,omitempty" json:"required,omitempty"`                     // Required - XSD: required element from conditions.xsd
	AllowGear          *common.AllowGear  `xml:"allowgear,omitempty" json:"allowgear,omitempty"`                   // Allow gear - XSD: from gear.xsd
	AllowSubsystems    *AllowSubsystems   `xml:"allowsubsystems,omitempty" json:"allowsubsystems,omitempty"`       // Allow subsystems - XSD: minOccurs="0"
	PairInclude        *PairInclude       `xml:"includepair,omitempty" json:"pairinclude,omitempty"`               // Pair include - XSD: minOccurs="0"
	PairBonus          *common.PairBonus  `xml:"pairbonus,omitempty" json:"pairbonus,omitempty"`                   // Pair bonus - XSD: from bonuses.xsd
	Subsystems         interface{}        `xml:"subsystems,omitempty" json:"subsystems,omitempty"`                 // Subsystems - XSD: subsystems element (complex, TODO: type properly)
}

// Note: stringPtr and intPtr helper functions are defined in lifestyles_data.go (shared across XML-generated files)

package v5

import "testing"

func TestDataArmors(t *testing.T) {
	if len(DataArmors) == 0 {
		t.Error("DataArmors should not be empty")
	}
	
	// Test that we can access a specific armor
	for id, armor := range DataArmors {
		if id == "" {
			t.Error("Armor ID should not be empty")
		}
		if armor.Name == "" {
			t.Errorf("Armor %s should have a name", id)
		}
		if armor.Category == "" {
			t.Errorf("Armor %s should have a category", id)
		}
		if armor.Armor == "" {
			t.Errorf("Armor %s should have an armor value", id)
		}
		if armor.ArmorCapacity == "" {
			t.Errorf("Armor %s should have an armor capacity", id)
		}
		if armor.Source == "" {
			t.Errorf("Armor %s should have a source", id)
		}
	}
}

func TestDataArmorMods(t *testing.T) {
	if len(DataArmorMods) == 0 {
		t.Error("DataArmorMods should not be empty")
	}
	
	// Test that we can access a specific mod
	for id, mod := range DataArmorMods {
		if id == "" {
			t.Error("Mod ID should not be empty")
		}
		if mod.Name == "" {
			t.Errorf("Mod %s should have a name", id)
		}
		if mod.Category == "" {
			t.Errorf("Mod %s should have a category", id)
		}
		if mod.MaxRating == "" {
			t.Errorf("Mod %s should have a max rating", id)
		}
		if mod.ArmorCapacity == "" {
			t.Errorf("Mod %s should have an armor capacity", id)
		}
		if mod.Source == "" {
			t.Errorf("Mod %s should have a source", id)
		}
	}
}

func TestDataCategories(t *testing.T) {
	if len(DataCategories) == 0 {
		t.Error("DataCategories should not be empty")
	}
}

func TestDataModCategories(t *testing.T) {
	if len(DataModCategories) == 0 {
		t.Error("DataModCategories should not be empty")
	}
}

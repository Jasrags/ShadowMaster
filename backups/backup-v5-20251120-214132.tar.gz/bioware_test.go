package v5

import "testing"

func TestDataBiowares(t *testing.T) {
	if len(DataBiowares) == 0 {
		t.Error("DataBiowares should not be empty")
	}
	
	// Test that we can access a specific bioware
	for id, bioware := range DataBiowares {
		if id == "" {
			t.Error("Bioware ID should not be empty")
		}
		if bioware.Name == "" {
			t.Errorf("Bioware %s should have a name", id)
		}
		if bioware.Category == "" {
			t.Errorf("Bioware %s should have a category", id)
		}
		if bioware.Ess == "" {
			t.Errorf("Bioware %s should have an essence cost", id)
		}
		if bioware.Capacity == "" {
			t.Errorf("Bioware %s should have a capacity", id)
		}
		if bioware.Source == "" {
			t.Errorf("Bioware %s should have a source", id)
		}
	}
}

func TestDataGrades(t *testing.T) {
	if len(DataGrades) == 0 {
		t.Error("DataGrades should not be empty")
	}
}

func TestDataBiowareCategories(t *testing.T) {
	if len(DataBiowareCategories) == 0 {
		t.Error("DataBiowareCategories should not be empty")
	}
}

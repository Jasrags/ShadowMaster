package v5

import "shadowmaster/pkg/shadowrun/edition/v5/common"

// Note: Chummer root element is defined in books.go (shared across XML files)

// Category represents an armor or mod category with its black market classification
// XSD: category element with blackmarket attribute (xs:string, optional) and text content (xs:string)
type Category struct {
	Name        string `xml:",chardata" json:"name"`         // Category name
	BlackMarket string `xml:"blackmarket,attr,omitempty" json:"black_market"` // Black market classification
}

// SelectModsFromCategory represents a category to select mods from
// XSD: selectmodsfromcategory element containing category elements (minOccurs="1", maxOccurs="unbounded")
type SelectModsFromCategory struct {
	Category []string `xml:"category" json:"category"` // Categories to select mods from - XSD: minOccurs="1", maxOccurs="unbounded"
}

// Gears represents gears that can be used with armor
// XSD: gears element containing usegear elements (minOccurs="1", maxOccurs="unbounded")
type Gears struct {
	UseGear []UseGear `xml:"usegear" json:"usegear"` // Array of gear entries - XSD: minOccurs="1", maxOccurs="unbounded"
}

// UseGear represents a gear entry with optional rating and select attributes
// XSD: usegear element with rating (xs:integer, optional) and select (xs:string, optional) attributes, text content (xs:string)
type UseGear struct {
	Content string `xml:",chardata" json:"+content,omitempty"` // Gear name
	Rating  *int   `xml:"rating,attr,omitempty" json:"+@rating,omitempty"` // Optional rating - XSD: xs:integer, optional
	Select  string `xml:"select,attr,omitempty" json:"+@select,omitempty"` // Optional selection - XSD: xs:string, optional
}

// Mods represents pre-installed mods on armor
// XSD: mods element containing name elements (minOccurs="1", maxOccurs="unbounded")
type Mods struct {
	Name []ModName `xml:"name" json:"name"` // Array of mod names - XSD: minOccurs="1", maxOccurs="unbounded"
}

// ModName represents a mod name entry with optional rating attribute
// XSD: name element with rating (xs:integer, optional) attribute, text content (xs:string)
type ModName struct {
	Content string `xml:",chardata" json:"+content,omitempty"` // Mod name
	Rating  *int   `xml:"rating,attr,omitempty" json:"+@rating,omitempty"` // Optional rating - XSD: xs:integer, optional
}

// Bonus represents bonuses provided by armor or mods
// XSD: bonus element of type bonusTypes (from bonuses.xsd)
// Note: This is a simplified version focusing on common bonus types used in armor
// The full bonusTypes from bonuses.xsd is very complex with many possible fields
type Bonus struct {
	// Limit modifiers
	LimitModifier []common.LimitModifier `xml:"limitmodifier,omitempty" json:"limitmodifier,omitempty"` // XSD: minOccurs="0", maxOccurs="unbounded"

	// Skill bonuses
	SkillCategory []common.SkillCategoryBonus `xml:"skillcategory,omitempty" json:"skillcategory,omitempty"` // XSD: minOccurs="0", maxOccurs="unbounded"
	SpecificSkill []common.SpecificSkillBonus `xml:"specificskill,omitempty" json:"specificskill,omitempty"` // XSD: minOccurs="0", maxOccurs="unbounded"

	// Social limit
	SocialLimit string `xml:"sociallimit,omitempty" json:"sociallimit,omitempty"` // XSD: xs:string, minOccurs="0"

	// Resistance/immunity bonuses
	ToxinContactResist       string `xml:"toxincontactresist,omitempty" json:"toxincontactresist,omitempty"` // XSD: xs:string, minOccurs="0"
	ToxinContactImmune       bool   `xml:"toxincontactimmune,omitempty" json:"toxincontactimmune,omitempty"` // XSD: xs:boolean, minOccurs="0"
	ToxinInhalationImmune    bool   `xml:"toxininhalationimmune,omitempty" json:"toxininhalationimmune,omitempty"` // XSD: xs:boolean, minOccurs="0"
	PathogenContactResist    string `xml:"pathogencontactresist,omitempty" json:"pathogencontactresist,omitempty"` // XSD: xs:string, minOccurs="0"
	PathogenContactImmune    bool   `xml:"pathogencontactimmune,omitempty" json:"pathogencontactimmune,omitempty"` // XSD: xs:boolean, minOccurs="0"
	PathogenInhalationImmune bool   `xml:"pathogeninhalationimmune,omitempty" json:"pathogeninhalationimmune,omitempty"` // XSD: xs:boolean, minOccurs="0"

	// Armor bonuses
	FireArmor        string `xml:"firearmor,omitempty" json:"firearmor,omitempty"`         // XSD: xs:string, minOccurs="0"
	ColdArmor        string `xml:"coldarmor,omitempty" json:"coldarmor,omitempty"`         // XSD: xs:string, minOccurs="0"
	ElectricityArmor string `xml:"electricityarmor,omitempty" json:"electricityarmor,omitempty"` // XSD: xs:string, minOccurs="0"

	// Radiation resistance
	RadiationResist string `xml:"radiationresist,omitempty" json:"radiationresist,omitempty"` // XSD: xs:string, minOccurs="0"

	// Fatigue resistance
	FatigueResist string `xml:"fatigueresist,omitempty" json:"fatigueresist,omitempty"` // XSD: xs:string, minOccurs="0"

	// Select armor
	SelectArmor bool `xml:"selectarmor,omitempty" json:"selectarmor,omitempty"` // XSD: xs:boolean, minOccurs="0"

	// Unique identifier
	Unique string `xml:"unique,attr,omitempty" json:"+@unique,omitempty"` // XSD: xs:string, optional attribute

	// Select text
	SelectText bool `xml:"selecttext,omitempty" json:"selecttext,omitempty"` // XSD: xs:boolean, minOccurs="0"
}

// Armor represents a piece of armor from Shadowrun 5th Edition
// XSD: armor element with required and optional fields
type Armor struct {
	// Required fields (minOccurs="1")
	ID            string `xml:"id" json:"id"`                       // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"
	Name          string `xml:"name" json:"name"`                   // Armor name - XSD: xs:string, minOccurs="1"
	Category      string `xml:"category" json:"category"`           // Category - XSD: xs:string, minOccurs="1"
	Armor         string `xml:"armor" json:"armor"`                 // Armor value - XSD: xs:string, minOccurs="1"
	ArmorCapacity string `xml:"armorcapacity" json:"armorcapacity"` // Armor capacity - XSD: xs:string, minOccurs="1"
	Avail         string `xml:"avail" json:"avail"`                 // Availability - XSD: xs:string, minOccurs="1"
	Cost          string `xml:"cost" json:"cost"`                   // Cost - XSD: xs:string, minOccurs="1"
	Source        string `xml:"source" json:"source"`               // Source book - XSD: xs:string, minOccurs="1"
	Page          string `xml:"page" json:"page"`                   // Page number - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Hide                  *string                 `xml:"hide,omitempty" json:"hide,omitempty"`                               // Hide flag - XSD: xs:string, minOccurs="0"
	IgnoreSourceDisabled  *string                 `xml:"ignoresourcedisabled,omitempty" json:"ignoresourcedisabled,omitempty"` // Ignore source disabled - XSD: xs:string, minOccurs="0"
	Rating                *string                 `xml:"rating,omitempty" json:"rating,omitempty"`                           // Rating - XSD: xs:string, minOccurs="0"
	ArmorOverride         *string                 `xml:"armoroverride,omitempty" json:"armoroverride,omitempty"`             // Armor override - XSD: xs:string, minOccurs="0"
	GearCapacity          *string                 `xml:"gearcapacity,omitempty" json:"gearcapacity,omitempty"`               // Gear capacity - XSD: xs:string, minOccurs="0"
	PhysicalLimit         *string                 `xml:"physicallimit,omitempty" json:"physicallimit,omitempty"`             // Physical limit - XSD: xs:string, minOccurs="0"
	SocialLimit           *string                 `xml:"sociallimit,omitempty" json:"sociallimit,omitempty"`                 // Social limit - XSD: xs:string, minOccurs="0"
	AddModCategory        *string                 `xml:"addmodcategory,omitempty" json:"addmodcategory,omitempty"`           // Add mod category - XSD: xs:string, minOccurs="0"
	ForceModCategory      *string                 `xml:"forcemodcategory,omitempty" json:"forcemodcategory,omitempty"`       // Force mod category - XSD: xs:string, minOccurs="0"
	AddonCategory         []string                `xml:"addoncategory,omitempty" json:"addoncategory,omitempty"`             // Addon categories - XSD: xs:string, minOccurs="0", maxOccurs="unbounded"
	AddWeapon             []string                `xml:"addweapon,omitempty" json:"addweapon,omitempty"`                     // Add weapon - XSD: xs:string, minOccurs="0", maxOccurs="unbounded"
	SelectModsFromCategory *SelectModsFromCategory `xml:"selectmodsfromcategory,omitempty" json:"selectmodsfromcategory,omitempty"` // Select mods from category - XSD: minOccurs="0"
	Bonus                 *Bonus                  `xml:"bonus,omitempty" json:"bonus,omitempty"`                             // Bonus - XSD: bonusTypes, minOccurs="0"
	WirelessBonus         *Bonus                  `xml:"wirelessbonus,omitempty" json:"wirelessbonus,omitempty"`             // Wireless bonus - XSD: bonusTypes, minOccurs="0"
	Mods                  *Mods                   `xml:"mods,omitempty" json:"mods,omitempty"`                               // Pre-installed mods - XSD: minOccurs="0"
	Gears                 *Gears                  `xml:"gears,omitempty" json:"gears,omitempty"`                             // Gears - XSD: minOccurs="0"
	Forbidden             interface{}             `xml:"forbidden,omitempty" json:"forbidden,omitempty"`                     // Forbidden conditions - XSD: forbidden element from conditions.xsd (complex, TODO: type properly)
	Required              interface{}             `xml:"required,omitempty" json:"required,omitempty"`                       // Required conditions - XSD: required element from conditions.xsd (complex, TODO: type properly)
}

// ArmorMod represents an armor modification from Shadowrun 5th Edition
// XSD: mod element with required and optional fields
type ArmorMod struct {
	// Required fields (minOccurs="1")
	ID            string `xml:"id" json:"id"`                       // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"
	Name          string `xml:"name" json:"name"`                   // Mod name - XSD: xs:string, minOccurs="1"
	Category      string `xml:"category" json:"category"`           // Category - XSD: xs:string, minOccurs="1"
	MaxRating     string `xml:"maxrating" json:"maxrating"`         // Maximum rating - XSD: xs:string, minOccurs="1"
	ArmorCapacity string `xml:"armorcapacity" json:"armorcapacity"` // Armor capacity - XSD: xs:string, minOccurs="1"
	Avail         string `xml:"avail" json:"avail"`                 // Availability - XSD: xs:string, minOccurs="1"
	Cost          string `xml:"cost" json:"cost"`                   // Cost - XSD: xs:string, minOccurs="1"
	Source        string `xml:"source" json:"source"`               // Source book - XSD: xs:string, minOccurs="1"
	Page          string `xml:"page" json:"page"`                   // Page number - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Armor          *string    `xml:"armor,omitempty" json:"armor,omitempty"`                   // Armor value - XSD: xs:string, minOccurs="0"
	Hide           *string    `xml:"hide,omitempty" json:"hide,omitempty"`                     // Hide flag - XSD: xs:string, minOccurs="0"
	IgnoreSourceDisabled *string `xml:"ignoresourcedisabled,omitempty" json:"ignoresourcedisabled,omitempty"` // Ignore source disabled - XSD: xs:string, minOccurs="0"
	AddWeapon      []string   `xml:"addweapon,omitempty" json:"addweapon,omitempty"`           // Add weapon - XSD: xs:string, minOccurs="0", maxOccurs="unbounded"
	Bonus          *Bonus     `xml:"bonus,omitempty" json:"bonus,omitempty"`                   // Bonus - XSD: bonusTypes, minOccurs="0"
	WirelessBonus  *Bonus     `xml:"wirelessbonus,omitempty" json:"wirelessbonus,omitempty"`   // Wireless bonus - XSD: bonusTypes, minOccurs="0"
	Gears          *Gears     `xml:"gears,omitempty" json:"gears,omitempty"`                   // Gears - XSD: minOccurs="0"
	Forbidden      interface{} `xml:"forbidden,omitempty" json:"forbidden,omitempty"`          // Forbidden conditions - XSD: forbidden element from conditions.xsd (complex, TODO: type properly)
	Required       interface{} `xml:"required,omitempty" json:"required,omitempty"`            // Required conditions - XSD: required element from conditions.xsd (complex, TODO: type properly)
}

// Note: stringPtr and intPtr helper functions are defined in lifestyles.go (shared across XML-generated files)

package v5

// Note: Chummer root element is defined in books.go (shared across XML files)

// FreeGrid represents a free grid subscription
// XSD: freegrid element with select attribute (xs:string) and text content (xs:string)
type FreeGrid struct {
	Content string `xml:",chardata" json:"+content,omitempty"` // Content like "Grid Subscription"
	Select  string `xml:"select,attr,omitempty" json:"+@select,omitempty"` // Selection like "Public Grid", "Local Grid", "Global Grid"
}

// FreeGrids represents a collection of free grids
// XSD: freegrids element containing freegrid elements (maxOccurs="unbounded")
type FreeGrids struct {
	FreeGrid []FreeGrid `xml:"freegrid,omitempty" json:"freegrid,omitempty"` // Slice of free grids (XSD: maxOccurs="unbounded")
}

// Lifestyle represents a lifestyle from Shadowrun 5th Edition
// XSD: lifestyle element with required and optional fields
type Lifestyle struct {
	// Required fields (minOccurs="1")
	ID         string `xml:"id" json:"id"`         // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"
	Name       string `xml:"name" json:"name"`     // Lifestyle name - XSD: xs:string, minOccurs="1"
	Cost       string `xml:"cost" json:"cost"`     // Base cost - XSD: xs:string, minOccurs="1"
	Dice       string `xml:"dice" json:"dice"`     // Dice pool - XSD: xs:string, minOccurs="1"
	LP         string `xml:"lp" json:"lp"`         // Lifestyle points - XSD: xs:string, minOccurs="1"
	Multiplier string `xml:"multiplier" json:"multiplier"` // Cost multiplier - XSD: xs:string, minOccurs="1"
	Source     string `xml:"source" json:"source"` // Source book like "SR5", "RF", etc. - XSD: xs:string, minOccurs="1"
	Page       string `xml:"page" json:"page"`     // Page number - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Hide            *string     `xml:"hide,omitempty" json:"hide,omitempty"`            // Hide flag - XSD: xs:string, minOccurs="0"
	FreeGrids       *FreeGrids  `xml:"freegrids,omitempty" json:"freegrids,omitempty"`  // Free grid subscriptions - XSD: minOccurs="0"
	CostForArea     *int        `xml:"costforarea,omitempty" json:"costforarea,omitempty"`     // Cost for area - XSD: xs:integer, minOccurs="0"
	CostForComforts *int        `xml:"costforcomforts,omitempty" json:"costforcomforts,omitempty"` // Cost for comforts - XSD: xs:integer, minOccurs="0"
	CostForSecurity *int        `xml:"costforsecurity,omitempty" json:"costforsecurity,omitempty"` // Cost for security - XSD: xs:integer, minOccurs="0"
	Increment       *string     `xml:"increment,omitempty" json:"increment,omitempty"`       // Time increment like "day" - XSD: xs:string, minOccurs="0"
	AllowBonusLP    *string     `xml:"allowbonuslp,omitempty" json:"allowbonuslp,omitempty"`    // Whether to allow bonus LP - XSD: xs:string, minOccurs="0"
}

// Comfort represents a lifestyle comfort option
// XSD: comfort element with name (xs:string, minOccurs="1"), minimum (xs:integer, minOccurs="1"), limit (xs:integer, minOccurs="0")
type Comfort struct {
	Name    string `xml:"name" json:"name"`    // Comfort name - XSD: xs:string, minOccurs="1"
	Minimum int    `xml:"minimum" json:"minimum"` // Minimum rating - XSD: xs:integer, minOccurs="1"
	Limit   *int   `xml:"limit,omitempty" json:"limit,omitempty"`   // Maximum rating - XSD: xs:integer, minOccurs="0"
}

// Neighborhood represents a lifestyle neighborhood option
// XSD: neighborhood element with name (xs:string, minOccurs="1"), minimum (xs:integer, minOccurs="1"), limit (xs:integer, minOccurs="0")
type Neighborhood struct {
	Name    string `xml:"name" json:"name"`    // Neighborhood name - XSD: xs:string, minOccurs="1"
	Minimum int    `xml:"minimum" json:"minimum"` // Minimum rating - XSD: xs:integer, minOccurs="1"
	Limit   *int   `xml:"limit,omitempty" json:"limit,omitempty"`   // Maximum rating - XSD: xs:integer, minOccurs="0"
}

// Security represents a lifestyle security option
// XSD: security element with name (xs:string, minOccurs="1"), minimum (xs:integer, minOccurs="1"), limit (xs:integer, minOccurs="0")
type Security struct {
	Name    string `xml:"name" json:"name"`    // Security name - XSD: xs:string, minOccurs="1"
	Minimum int    `xml:"minimum" json:"minimum"` // Minimum rating - XSD: xs:integer, minOccurs="1"
	Limit   *int   `xml:"limit,omitempty" json:"limit,omitempty"`   // Maximum rating - XSD: xs:integer, minOccurs="0"
}

// LifestyleQualityBonus represents bonus elements for lifestyle qualities
// XSD: bonus element containing selecttext elements (maxOccurs="unbounded")
type LifestyleQualityBonus struct {
	SelectText []LifestyleQualitySelectText `xml:"selecttext,omitempty" json:"selecttext,omitempty"` // Select text options - XSD: maxOccurs="unbounded"
}

// LifestyleQualitySelectText represents a selecttext element with attributes
// XSD: selecttext element with xml, xpath, allowedit, select attributes (all optional)
type LifestyleQualitySelectText struct {
	Content   string `xml:",chardata" json:"+content,omitempty"` // Text content
	XML       string `xml:"xml,attr,omitempty" json:"+@xml,omitempty"` // XML attribute
	XPath     string `xml:"xpath,attr,omitempty" json:"+@xpath,omitempty"` // XPath attribute
	AllowEdit string `xml:"allowedit,attr,omitempty" json:"+@allowedit,omitempty"` // AllowEdit attribute
	Select    string `xml:"select,attr,omitempty" json:"+@select,omitempty"` // Select attribute
}

// LifestyleQualityRequired represents required elements (from conditions.xsd)
// This is a complex type that can contain various requirement checks
// For now, we'll use interface{} but document it properly
type LifestyleQualityRequired struct {
	// TODO: Implement proper struct based on conditions.xsd
	// This can contain oneof, allof, and various check elements
	// Keeping as interface{} for now due to complexity
	Data interface{} `xml:",innerxml" json:"data,omitempty"`
}

// LifestyleQualityForbidden represents forbidden elements (from conditions.xsd)
// Similar to Required, this is complex
type LifestyleQualityForbidden struct {
	// TODO: Implement proper struct based on conditions.xsd
	Data interface{} `xml:",innerxml" json:"data,omitempty"`
}

// LifestyleQuality represents a lifestyle quality
// XSD: quality element with many optional fields
type LifestyleQuality struct {
	// Required fields (minOccurs="1")
	ID       string `xml:"id" json:"id"`       // Unique identifier (UUID) - XSD: xs:string, minOccurs="1"
	Name     string `xml:"name" json:"name"`     // Quality name - XSD: xs:string, minOccurs="1"
	Category string `xml:"category" json:"category"` // Category like "Entertainment - Asset", etc. - XSD: xs:string, minOccurs="1"
	LP       int    `xml:"lp" json:"lp"`       // Lifestyle points cost - XSD: xs:integer, minOccurs="1"
	Source   string `xml:"source" json:"source"`   // Source book - XSD: xs:string, minOccurs="1"
	Page     string `xml:"page" json:"page"`     // Page number - XSD: xs:string, minOccurs="1"

	// Optional fields (minOccurs="0")
	Hide                *string                   `xml:"hide,omitempty" json:"hide,omitempty"`                // Hide flag - XSD: xs:string, minOccurs="0"
	Cost                *string                   `xml:"cost,omitempty" json:"cost,omitempty"`                // Cost - XSD: xs:string, minOccurs="0"
	Bonus               *LifestyleQualityBonus    `xml:"bonus,omitempty" json:"bonus,omitempty"`               // Bonus elements - XSD: minOccurs="0"
	Multiplier          *int                      `xml:"multiplier,omitempty" json:"multiplier,omitempty"`          // Multiplier - XSD: xs:integer, minOccurs="0"
	MultiplierBaseOnly  *int                      `xml:"multiplierbaseonly,omitempty" json:"multiplierbaseonly,omitempty"`  // Multiplier base only - XSD: xs:integer, minOccurs="0"
	AreaMaximum         *int                      `xml:"areamaximum,omitempty" json:"areamaximum,omitempty"`         // Area maximum - XSD: xs:integer, minOccurs="0"
	ComfortsMaximum     *int                      `xml:"comfortsmaximum,omitempty" json:"comfortsmaximum,omitempty"`     // Comforts maximum - XSD: xs:integer, minOccurs="0"
	SecurityMaximum     *int                      `xml:"securitymaximum,omitempty" json:"securitymaximum,omitempty"`     // Security maximum - XSD: xs:integer, minOccurs="0"
	AreaMinimum         *int                      `xml:"areaminimum,omitempty" json:"areaminimum,omitempty"`         // Area minimum - XSD: xs:integer, minOccurs="0"
	ComfortsMinimum     *int                      `xml:"comfortsminimum,omitempty" json:"comfortsminimum,omitempty"`     // Comforts minimum - XSD: xs:integer, minOccurs="0"
	SecurityMinimum     *int                      `xml:"securityminimum,omitempty" json:"securityminimum,omitempty"`     // Security minimum - XSD: xs:integer, minOccurs="0"
	Area                *int                      `xml:"area,omitempty" json:"area,omitempty"`                // Area - XSD: xs:integer, minOccurs="0"
	Comforts            *int                      `xml:"comforts,omitempty" json:"comforts,omitempty"`            // Comforts - XSD: xs:integer, minOccurs="0"
	Security            *int                      `xml:"security,omitempty" json:"security,omitempty"`            // Security - XSD: xs:integer, minOccurs="0"
	Allowed             *string                   `xml:"allowed,omitempty" json:"allowed,omitempty"`             // Allowed lifestyles (comma-separated) - XSD: xs:string, minOccurs="0"
	AllowMultiple       *string                   `xml:"allowmultiple,omitempty" json:"allowmultiple,omitempty"`       // Allow multiple flag (empty element) - XSD: minOccurs="0"
	Required            *LifestyleQualityRequired `xml:"required,omitempty" json:"required,omitempty"`            // Required elements - XSD: ref="required", minOccurs="0"
	Forbidden           *LifestyleQualityForbidden `xml:"forbidden,omitempty" json:"forbidden,omitempty"`           // Forbidden elements - XSD: ref="forbidden", minOccurs="0"
}

// Borough represents a borough within a district
// XSD: borough element with name (xs:string, minOccurs="1") and secRating (xs:string, minOccurs="0")
type Borough struct {
	Name     string  `xml:"name" json:"name"`     // Borough name - XSD: xs:string, minOccurs="1"
	SecRating *string `xml:"secRating,omitempty" json:"secRating,omitempty"` // Security rating - XSD: xs:string, minOccurs="0"
}

// District represents a district within a city
// XSD: district element with name (xs:string, minOccurs="1") and borough elements (maxOccurs="unbounded")
type District struct {
	Name     string    `xml:"name" json:"name"`     // District name - XSD: xs:string, minOccurs="1"
	Boroughs []Borough `xml:"borough,omitempty" json:"borough,omitempty"` // Boroughs - XSD: maxOccurs="unbounded"
}

// City represents a city for lifestyles
// XSD: city element with name (xs:string, minOccurs="1") and district elements (maxOccurs="unbounded")
type City struct {
	Name      string     `xml:"name" json:"name"`      // City name - XSD: xs:string, minOccurs="1"
	Districts []District `xml:"district,omitempty" json:"district,omitempty"` // Districts - XSD: maxOccurs="unbounded"
}

package v5

import "shadowmaster/pkg/shadowrun/edition/v5/common"

// Quality represents a quality (positive or negative) from Shadowrun 5th Edition
type Quality struct {
	// Required fields
	Name     string `json:"name"`     // JSON: string (e.g., "Ambidextrous", "Analytical Mind")
	Karma    string `json:"karma"`    // JSON: string (e.g., "4", "5", "-7") - can be negative for negative qualities
	Category string `json:"category"` // JSON: string - "Positive" or "Negative"
	Source   string `json:"source"`   // JSON: string (e.g., "SR5", "RF", "DT") - source book abbreviation

	// Optional fields
	Limit                 string            `json:"limit,omitempty"`                 // JSON: string (e.g., "{arm} - 1", "False", "3") - limit formula or value
	Bonus                 *QualityBonus     `json:"bonus,omitempty"`                 // JSON: object or null - bonuses provided by this quality
	Required              *QualityRequired  `json:"required,omitempty"`              // JSON: object with "oneof" or "allof" - requirements for this quality
	Forbidden             *QualityForbidden `json:"forbidden,omitempty"`             // JSON: object with "oneof" - forbidden items/qualities
	Page                  string            `json:"page,omitempty"`                  // JSON: string (e.g., "71", "72", "156") - page number in source book
	ChargenOnly           bool              `json:"chargenonly,omitempty"`           // JSON: null or true - whether only available at character creation
	CareerOnly            bool              `json:"careeronly,omitempty"`            // JSON: boolean - whether only available during career
	Mutant                string            `json:"mutant,omitempty"`                // JSON: string (e.g., "True") or null - mutant flag
	Metagenic             string            `json:"metagenic,omitempty"`             // JSON: string or null - metagenic flag
	NoLevels              bool              `json:"nolevels,omitempty"`              // JSON: boolean - whether this quality has no levels
	StagedPurchase        bool              `json:"stagedpurchase,omitempty"`        // JSON: boolean - whether this can be purchased in stages
	RefundKarmaOnRemove   bool              `json:"refundkarmaonremove,omitempty"`   // JSON: boolean - whether karma is refunded on removal
	ContributeToBP        bool              `json:"contributetobp,omitempty"`        // JSON: boolean - whether this contributes to build points
	ContributeToLimit     bool              `json:"contributetolimit,omitempty"`     // JSON: string (e.g., "False") or boolean - whether this contributes to limits
	IncludeInLimit        *IncludeInLimit   `json:"includeinlimit,omitempty"`        // JSON: object - whether included in limit calculations
	LimitWithinInclusions bool              `json:"limitwithinclusions,omitempty"`   // JSON: boolean - limit within inclusions
	OnlyPriorityGiven     bool              `json:"onlyprioritygiven,omitempty"`     // JSON: null or boolean - only available with priority
	CanBuyWithSpellPoints bool              `json:"canbuywithspellpoints,omitempty"` // JSON: boolean - can be bought with spell points
	DoubleCareer          bool              `json:"doublecareer,omitempty"`          // JSON: boolean - double career flag
	ChargenLimit          string            `json:"chargenlimit,omitempty"`          // JSON: string - character generation limit
	CostDiscount          string            `json:"costdiscount,omitempty"`          // JSON: string - cost discount
	FirstLevelBonus       bool              `json:"firstlevelbonus,omitempty"`       // JSON: boolean - first level bonus
	Hide                  bool              `json:"hide,omitempty"`                  // JSON: null or boolean - whether to hide this quality
	Implemented           bool              `json:"implemented,omitempty"`           // JSON: boolean - whether implemented
	NameOnPage            string            `json:"nameonpage,omitempty"`            // JSON: string - name as it appears on page
	NaturalWeapons        *NaturalWeapons   `json:"naturalweapons,omitempty"`        // JSON: object - natural weapons structure
	AddWeapon             string            `json:"addweapon,omitempty"`             // JSON: string - weapon added by this quality
}

// QualityBonus represents bonuses provided by a quality
// This is a very flexible structure with many possible bonus types
type QualityBonus struct {
	// Many fields similar to BiowareBonus but with additional quality-specific ones
	// For now, we'll use a flexible approach with interface{} for complex nested structures

	// Common bonus fields (similar to bioware)
	LimitModifier            *common.LimitModifier            `json:"limitmodifier,omitempty"`            // JSON: object with "limit", "value", "condition"
	SkillCategory            *BiowareSkillCategoryBonus       `json:"skillcategory,omitempty"`            // JSON: object with "name", "bonus"
	SpecificSkill            []common.SpecificSkillBonus      `json:"specificskill,omitempty"`            // JSON: array of objects with "name", "bonus" (e.g., [{"name": "Sneaking", "bonus": 2}])
	SkillGroup               []*common.SkillGroupBonus        `json:"skillgroup,omitempty"`               // JSON: array of objects with "name", "bonus", "condition"
	SelectSkill              interface{}                      `json:"selectskill,omitempty"`              // JSON: object with "max", "val", etc. (e.g., {"max": "1"})
	SkillAttribute           *common.SkillAttributeBonus      `json:"skillattribute,omitempty"`           // JSON: object with "name", "bonus", "condition" (e.g., {"name": "LOG", "bonus": "2"})
	SpecificAttribute        []*common.SpecificAttributeBonus `json:"specificattribute,omitempty"`        // JSON: array of objects with "name", "val", "max"
	PhysicalLimit            string                           `json:"physicallimit,omitempty"`            // JSON: string (e.g., "1")
	MentalLimit              string                           `json:"mentallimit,omitempty"`              // JSON: string (e.g., "1")
	SocialLimit              string                           `json:"sociallimit,omitempty"`              // JSON: string (e.g., "1")
	ConditionMonitor         *common.ConditionMonitorBonus    `json:"conditionmonitor,omitempty"`         // JSON: object with "sharedthresholdoffset", "thresholdoffset"
	Initiative               *common.InitiativeBonus          `json:"initiative,omitempty"`               // JSON: object with "+content", "+@precedence"
	InitiativePass           *common.InitiativePassBonus      `json:"initiativepass,omitempty"`           // JSON: object with "+content", "+@precedence"
	Dodge                    string                           `json:"dodge,omitempty"`                    // JSON: string
	DamageResistance         string                           `json:"damageresistance,omitempty"`         // JSON: string
	UnarmedDV                string                           `json:"unarmeddv,omitempty"`                // JSON: string
	UnarmedDVPhysical        bool                             `json:"unarmeddvphysical,omitempty"`        // JSON: boolean or null
	UnarmedReach             string                           `json:"unarmedreach,omitempty"`             // JSON: string
	Armor                    interface{}                      `json:"armor,omitempty"`                    // JSON shows: object with "+content" and "+@group" (e.g., {"+content": "2", "+@group": "0"}) or string (e.g., "1")
	FireArmor                string                           `json:"firearmor,omitempty"`                // JSON: string (e.g., "2")
	ColdArmor                string                           `json:"coldarmor,omitempty"`                // JSON: string (e.g., "2", "4")
	ElectricityArmor         string                           `json:"electricityarmor,omitempty"`         // JSON: string
	ToxinContactResist       string                           `json:"toxincontactresist,omitempty"`       // JSON: string (e.g., "1")
	ToxinIngestionResist     string                           `json:"toxiningestionresist,omitempty"`     // JSON: string
	ToxinInhalationResist    string                           `json:"toxininhalationresist,omitempty"`    // JSON: string
	ToxinInjectionResist     string                           `json:"toxininjectionresist,omitempty"`     // JSON: string
	PathogenContactResist    string                           `json:"pathogencontactresist,omitempty"`    // JSON: string (e.g., "1", "2")
	PathogenIngestionResist  string                           `json:"pathogeningestionresist,omitempty"`  // JSON: string
	PathogenInhalationResist string                           `json:"pathogeninhalationresist,omitempty"` // JSON: string
	PathogenInjectionResist  string                           `json:"pathogeninjectionresist,omitempty"`  // JSON: string
	RadiationResist          string                           `json:"radiationresist,omitempty"`          // JSON: string
	FatigueResist            string                           `json:"fatigueresist,omitempty"`            // JSON: string
	StunCMRecovery           string                           `json:"stuncmrecovery,omitempty"`           // JSON: string (e.g., "2")
	PhysicalCMRecovery       string                           `json:"physicalcmrecovery,omitempty"`       // JSON: string (e.g., "2")
	Memory                   string                           `json:"memory,omitempty"`                   // JSON: string (e.g., "2")
	DrainResist              string                           `json:"drainresist,omitempty"`              // JSON: string
	FadingResist             string                           `json:"fadingresist,omitempty"`             // JSON: string
	Composure                string                           `json:"composure,omitempty"`                // JSON: string
	LifestyleCost            string                           `json:"lifestylecost,omitempty"`            // JSON: string
	Ambidextrous             bool                             `json:"ambidextrous,omitempty"`             // JSON: null - flag indicating ambidextrous bonus

	// Quality-specific bonus fields
	Notoriety                                      string                  `json:"notoriety,omitempty"`                                      // JSON: string (e.g., "-1", "1", "3") - notoriety modifier
	PublicAwareness                                string                  `json:"publicawareness,omitempty"`                                // JSON: string - public awareness modifier
	Fame                                           string                  `json:"fame,omitempty"`                                           // JSON: string - fame modifier
	StreetCredMultiplier                           string                  `json:"streetcredmultiplier,omitempty"`                           // JSON: string - street cred multiplier
	AstralReputation                               string                  `json:"astralreputation,omitempty"`                               // JSON: string - astral reputation modifier
	NativeLanguageLimit                            string                  `json:"nativelanguagelimit,omitempty"`                            // JSON: string (e.g., "1") - native language limit
	KnowledgeskillPoints                           string                  `json:"knowledgeskillpoints,omitempty"`                           // JSON: string - knowledge skill points
	KnowledgeskillKarmaCost                        string                  `json:"knowledgeskillkarmacost,omitempty"`                        // JSON: string - knowledge skill karma cost
	KnowledgeskillKarmaCostMin                     string                  `json:"knowledgeskillkarmacostmin,omitempty"`                     // JSON: string - knowledge skill karma cost minimum
	ActiveskillKarmaCost                           string                  `json:"activeskillkarmacost,omitempty"`                           // JSON: string - active skill karma cost
	SkillCategoryKarmaCost                         string                  `json:"skillcategorykarmacost,omitempty"`                         // JSON: string - skill category karma cost
	SkillCategoryKarmaCostMultiplier               string                  `json:"skillcategorykarmacostmultiplier,omitempty"`               // JSON: string - skill category karma cost multiplier
	SkillCategoryPointCostMultiplier               string                  `json:"skillcategorypointcostmultiplier,omitempty"`               // JSON: string - skill category point cost multiplier
	SkillCategorySpecializationKarmaCostMultiplier string                  `json:"skillcategoryspecializationkarmacostmultiplier,omitempty"` // JSON: string - specialization karma cost multiplier
	SkillGroupCategoryKarmaCostMultiplier          string                  `json:"skillgroupcategorykarmacostmultiplier,omitempty"`          // JSON: string - skill group category karma cost multiplier
	NewspellKarmaCost                              string                  `json:"newspellkarmacost,omitempty"`                              // JSON: string - new spell karma cost
	FocusBindingKarmaCost                          string                  `json:"focusbindingkarmacost,omitempty"`                          // JSON: string - focus binding karma cost
	ContactKarma                                   string                  `json:"contactkarma,omitempty"`                                   // JSON: string - contact karma
	ContactKarmaMinimum                            string                  `json:"contactkarmaminimum,omitempty"`                            // JSON: string - contact karma minimum
	AddContact                                     interface{}             `json:"addcontact,omitempty"`                                     // JSON shows: object with "forcedloyalty", "forcegroup", "free", "group", "loyalty", "connection" (e.g., {"forcedloyalty": "3", "forcegroup": null})
	AddQuality                                     interface{}             `json:"addqualities,omitempty"`                                   // JSON shows: object with "addquality" (e.g., {"addquality": "SINner (Criminal)"})
	AddSkill                                       interface{}             `json:"addskillspecializationoption,omitempty"`                   // JSON shows: object with "spec" and "skills" (e.g., {"spec": "Electroception", "skills": {"skill": "Perception"}})
	AddSpell                                       interface{}             `json:"addspell,omitempty"`                                       // JSON shows: (no instances found in qualities.json)
	AddSpirit                                      interface{}             `json:"addspirit,omitempty"`                                      // JSON shows: array with nulls (e.g., [null, null]) or null
	AddEcho                                        interface{}             `json:"addecho,omitempty"`                                        // JSON shows: string (e.g., "Sourcerer Daemon")
	AddGear                                        interface{}             `json:"addgear,omitempty"`                                        // JSON shows: object with "name" and "category" (e.g., {"name": "Living Persona", "category": "Commlinks"})
	AddWare                                        interface{}             `json:"addware,omitempty"`                                        // JSON shows: (no instances found in qualities.json)
	AddLimb                                        interface{}             `json:"addlimb,omitempty"`                                        // JSON shows: object with "limbslot" and "val" (e.g., {"limbslot": "arm", "val": "2"})
	AddMetamagic                                   interface{}             `json:"addmetamagic,omitempty"`                                   // JSON shows: array of objects with "+content" and "+@forced" (e.g., [{"+content": "Psychometry", "+@forced": "True"}]) or single object
	SelectAttributes                               interface{}             `json:"selectattributes,omitempty"`                               // JSON shows: object with "selectattribute" (single or array) containing "excludeattribute", "max", "attribute", "val" (e.g., {"selectattribute": {"excludeattribute": "EDG", "max": "1"}} or {"selectattribute": [{"attribute": ["BOD", "REA", "STR"], "val": "1"}]})
	SelectContact                                  interface{}             `json:"selectcontact,omitempty"`                                  // JSON shows: null (e.g., "selectmentorspirit": null) - may be unused
	SelectExpertise                                string                  `json:"selectexpertise,omitempty"`                                // Selectable expertise (simple string field)
	SelectInherentAIProgram                        interface{}             `json:"selectinherentaiprogram,omitempty"`                        // JSON shows: (no instances found in qualities.json)
	SelectMentorSpirit                             interface{}             `json:"selectmentorspirit,omitempty"`                             // JSON shows: null (e.g., "selectmentorspirit": null) - may be unused
	SelectParagon                                  interface{}             `json:"selectparagon,omitempty"`                                  // JSON shows: (no instances found in qualities.json)
	SelectQuality                                  interface{}             `json:"selectquality,omitempty"`                                  // JSON shows: (no instances found in qualities.json)
	SelectSide                                     interface{}             `json:"selectside,omitempty"`                                     // JSON shows: (no instances found in qualities.json)
	SelectSprite                                   interface{}             `json:"selectsprite,omitempty"`                                   // JSON shows: (no instances found in qualities.json)
	SelectText                                     *common.SelectTextBonus `json:"selecttext,omitempty"`                                     // Selectable text bonus
	ActionDicePool                                 *ActionDicePool         `json:"actiondicepool,omitempty"`                                 // Action dice pool bonus
	SpellDicePool                                  string                  `json:"spelldicepool,omitempty"`                                  // JSON: object or string - spell dice pool bonus
	SpellResistance                                string                  `json:"spellresistance,omitempty"`                                // JSON: string (e.g., "1", "2") - spell resistance modifier
	SpellCategoryDamage                            string                  `json:"spellcategorydamage,omitempty"`                            // JSON: string - spell category damage modifier
	SpellCategoryDrain                             string                  `json:"spellcategorydrain,omitempty"`                             // JSON: string - spell category drain modifier
	SpellDescriptorDamage                          string                  `json:"spelldescriptordamage,omitempty"`                          // JSON: object - spell descriptor damage modifier
	SpellDescriptorDrain                           string                  `json:"spelldescriptordrain,omitempty"`                           // JSON: object - spell descriptor drain modifier
	AllowSpellCategory                             interface{}             `json:"allowspellcategory,omitempty"`                             // JSON shows: string (e.g., "Rituals")
	AllowSpellRange                                interface{}             `json:"allowspellrange,omitempty"`                                // JSON shows: array of strings (e.g., ["T", "T (A)"])
	LimitSpellCategory                             interface{}             `json:"limitspellcategory,omitempty"`                             // JSON shows: string (e.g., "Rituals")
	BlockSpellDescriptor                           interface{}             `json:"blockspelldescriptor,omitempty"`                           // JSON shows: string (e.g., "Spell")
	DefenseTest                                    string                  `json:"defensetest,omitempty"`                                    // JSON: string - defense test modifier
	Surprise                                       string                  `json:"surprise,omitempty"`                                       // JSON: string (e.g., "3", "-3", "-Rating") - surprise modifier
	Reach                                          string                  `json:"reach,omitempty"`                                          // JSON: string - reach modifier
	WalkMultiplier                                 string                  `json:"walkmultiplier,omitempty"`                                 // JSON: string - walk multiplier
	SprintBonus                                    string                  `json:"sprintbonus,omitempty"`                                    // JSON: object or string - sprint bonus
	RunMultiplier                                  string                  `json:"runmultiplier,omitempty"`                                  // JSON: string - run multiplier
	MovementReplace                                interface{}             `json:"movementreplace,omitempty"`                                // JSON shows: object with "category", "speed", "val" (e.g., {"category": "Ground", "speed": "run", "val": "6"}) or array of such objects
	WeaponCategoryDV                               string                  `json:"weaponcategorydv,omitempty"`                               // JSON: string - weapon category damage value modifier
	WeaponSkillAccuracy                            string                  `json:"weaponskillaccuracy,omitempty"`                            // JSON: string - weapon skill accuracy modifier
	EssenceMax                                     string                  `json:"essencemax,omitempty"`                                     // JSON: string - essence maximum modifier
	EssencePenalty                                 string                  `json:"essencepenalty,omitempty"`                                 // JSON: string - essence penalty
	EssencePenaltyMagonlyT100                      string                  `json:"essencepenaltymagonlyt100,omitempty"`                      // JSON: string - essence penalty magician-only threshold
	EssencePenaltyT100                             string                  `json:"essencepenaltyt100,omitempty"`                             // JSON: string - essence penalty threshold
	AddEssToPhysicalCMRecovery                     string                  `json:"addesstophysicalcmrecovery,omitempty"`                     // JSON: string - add essence to physical CM recovery
	AddEssToStunCMRecovery                         string                  `json:"addesstostuncmrecovery,omitempty"`                         // JSON: string - add essence to stun CM recovery
	BiowareEssMultiplier                           string                  `json:"biowareessmultiplier,omitempty"`                           // JSON: string - bioware essence multiplier
	CyberwareEssMultiplier                         string                  `json:"cyberwareessmultiplier,omitempty"`                         // JSON: string - cyberware essence multiplier
	CyberwareTotalEssMultiplier                    string                  `json:"cyberwaretotalessmultiplier,omitempty"`                    // JSON: string - cyberware total essence multiplier
	DisableBioware                                 interface{}             `json:"disablebioware,omitempty"`                                 // JSON shows: (no instances found in qualities.json)
	DisableBiowareGrade                            interface{}             `json:"disablebiowaregrade,omitempty"`                            // JSON shows: array of strings (e.g., ["Standard", "Standard (Burnout's Way)", "Used", "Alphaware", "Omegaware"])
	DisableCyberwareGrade                          interface{}             `json:"disablecyberwaregrade,omitempty"`                          // JSON shows: array of strings (e.g., ["Standard", "Standard (Burnout's Way)", "Used", "Alphaware", ...])
	SkillDisable                                   interface{}             `json:"skilldisable,omitempty"`                                   // JSON shows: string (e.g., "Binding") or array of strings (e.g., ["Summoning", "Binding"])
	SkillGroupDisable                              interface{}             `json:"skillgroupdisable,omitempty"`                              // JSON shows: string (e.g., "Conjuring") or array of strings (e.g., ["Sorcery", "Conjuring", "Enchanting"])
	SkillGroupDisableChoice                        interface{}             `json:"skillgroupdisablechoice,omitempty"`                        // JSON shows: (no instances found in qualities.json)
	SkillGroupCategoryDisable                      interface{}             `json:"skillgroupcategorydisable,omitempty"`                      // JSON shows: string (e.g., "Social Active")
	BlockSkillCategoryDefaulting                   interface{}             `json:"blockskillcategorydefaulting,omitempty"`                   // JSON shows: array of strings (e.g., ["Professional", "Academic", "Technical Active"])
	UnlockSkills                                   interface{}             `json:"unlockskills,omitempty"`                                   // JSON shows: string (e.g., "Magician", "Sorcery,Conjuring,Enchanting") or object with "+content" and "+@name" (e.g., {"+content": "Name", "+@name": "Assensing"}) or array of strings
	SwapSkillAttribute                             interface{}             `json:"swapskillattribute,omitempty"`                             // JSON shows: (no instances found in qualities.json)
	SwapSkillSpecAttribute                         interface{}             `json:"swapskillspecattribute,omitempty"`                         // JSON shows: (no instances found in qualities.json)
	EnableAttribute                                interface{}             `json:"enableattribute,omitempty"`                                // JSON shows: object with "name" (e.g., {"name": "MAG"})
	EnableTab                                      interface{}             `json:"enabletab,omitempty"`                                      // JSON shows: object with "name" (e.g., {"name": "magician"})
	ReplaceAttributes                              interface{}             `json:"replaceattributes,omitempty"`                              // JSON shows: (no instances found in qualities.json)
	RestrictGear                                   interface{}             `json:"restrictedgear,omitempty"`                                 // JSON shows: (no instances found in qualities.json)
	DealerConnection                               string                  `json:"dealerconnection,omitempty"`                               // JSON: string - dealer connection modifier
	BlackMarketDiscount                            string                  `json:"blackmarketdiscount,omitempty"`                            // JSON: string - black market discount
	BasicLifestyleCost                             string                  `json:"basiclifestylecost,omitempty"`                             // JSON: string - basic lifestyle cost modifier
	TrustFund                                      string                  `json:"trustfund,omitempty"`                                      // JSON: string - trust fund amount
	NuyenAmt                                       string                  `json:"nuyenamt,omitempty"`                                       // JSON: string - nuyen amount
	NuyenMaxBP                                     string                  `json:"nuyenmaxbp,omitempty"`                                     // JSON: string - nuyen maximum build points
	FriendsInHighPlaces                            string                  `json:"friendsinhighplaces,omitempty"`                            // JSON: string - friends in high places modifier
	MadeMan                                        string                  `json:"mademan,omitempty"`                                        // JSON: string - made man modifier
	ExCon                                          string                  `json:"excon,omitempty"`                                          // JSON: string or null - ex-con modifier
	Erased                                         string                  `json:"erased,omitempty"`                                         // JSON: string - erased modifier
	JudgeIntentionsDefense                         string                  `json:"judgeintentionsdefense,omitempty"`                         // JSON: string - judge intentions defense modifier
	JudgeIntentionsOffense                         string                  `json:"judgeintentionsoffense,omitempty"`                         // JSON: string - judge intentions offense modifier
	DecreaseIntResist                              string                  `json:"decreaseintresist,omitempty"`                              // JSON: string - decrease intuition resist
	DecreaseLogResist                              string                  `json:"decreaselogresist,omitempty"`                              // JSON: string - decrease logic resist
	DetectionSpellResist                           string                  `json:"detectionspellresist,omitempty"`                           // JSON: string - detection spell resistance
	ManaIllusionResist                             string                  `json:"manaillusionresist,omitempty"`                             // JSON: string - mana illusion resistance
	MentalManipulationResist                       string                  `json:"mentalmanipulationresist,omitempty"`                       // JSON: string - mental manipulation resistance
	PhysicalIllusionResist                         string                  `json:"physicalillusionresist,omitempty"`                         // JSON: string - physical illusion resistance
	DrainValue                                     string                  `json:"drainvalue,omitempty"`                                     // JSON: string - drain value modifier
	FadingValue                                    string                  `json:"fadingvalue,omitempty"`                                    // JSON: string - fading value modifier
	PhysiologicalAddictionFirstTime                string                  `json:"physiologicaladdictionfirsttime,omitempty"`                // JSON: string - physiological addiction first time threshold
	PsychologicalAddictionFirstTime                string                  `json:"psychologicaladdictionfirsttime,omitempty"`                // JSON: string - psychological addiction first time threshold
	PhysiologicalAddictionAlreadyAddicted          string                  `json:"physiologicaladdictionalreadyaddicted,omitempty"`          // JSON: string - physiological addiction already addicted threshold
	PsychologicalAddictionAlreadyAddicted          string                  `json:"psychologicaladdictionalreadyaddicted,omitempty"`          // JSON: string - psychological addiction already addicted threshold
	AdeptPowerPoints                               string                  `json:"adeptpowerpoints,omitempty"`                               // JSON: string - adept power points
	FreeSpells                                     string                  `json:"freespells,omitempty"`                                     // JSON: string - free spells
	FreeQuality                                    interface{}             `json:"freequality,omitempty"`                                    // JSON shows: string (UUID) (e.g., "ced3fecf-2277-4b20-b1e0-894162ca9ae2")
	MartialArt                                     interface{}             `json:"martialart,omitempty"`                                     // JSON shows: string (e.g., "One Trick Pony")
	OptionalPowers                                 interface{}             `json:"optionalpowers,omitempty"`                                 // JSON shows: (no instances found in qualities.json)
	CritterPowers                                  interface{}             `json:"critterpowers,omitempty"`                                  // JSON shows: (no instances found in qualities.json)
	LimitCritterPowerCategory                      interface{}             `json:"limitcritterpowercategory,omitempty"`                      // JSON shows: string (e.g., "Infected", "Drake")
	LimitSpiritCategory                            interface{}             `json:"limitspiritcategory,omitempty"`                            // JSON shows: (no instances found in qualities.json)
	AllowspriteFettering                           interface{}             `json:"allowspritefettering,omitempty"`                           // JSON shows: (no instances found in qualities.json)
	LivingPersona                                  interface{}             `json:"livingpersona,omitempty"`                                  // JSON shows: (no instances found in qualities.json)
	CyberAdeptDaemon                               interface{}             `json:"cyberadeptdaemon,omitempty"`                               // JSON shows: (no instances found in qualities.json)
	CyberSeeker                                    interface{}             `json:"cyberseeker,omitempty"`                                    // JSON shows: string (e.g., "WIL") or array of strings (e.g., ["AGI", "STR", "BOX"])
	Overclocker                                    interface{}             `json:"overclocker,omitempty"`                                    // JSON shows: (no instances found in qualities.json)
	PrototypeTranshuman                            interface{}             `json:"prototypetranshuman,omitempty"`                            // JSON shows: string (e.g., "1")
	BurnoutsWay                                    interface{}             `json:"burnoutsway,omitempty"`                                    // JSON shows: (no instances found in qualities.json)
	MagiciansWayDiscount                           string                  `json:"magicianswaydiscount,omitempty"`                           // JSON: string - magician's way discount
	MetagenicLimit                                 string                  `json:"metageniclimit,omitempty"`                                 // JSON: string - metagenic limit
	SpecialAttBurnMultiplier                       string                  `json:"specialattburnmultiplier,omitempty"`                       // JSON: string - special attribute burn multiplier
	SpecialModificationLimit                       string                  `json:"specialmodificationlimit,omitempty"`                       // JSON: string - special modification limit
	Unique                                         string                  `json:"+@unique,omitempty"`                                       // JSON: string - unique flag
	UseSelected                                    string                  `json:"+@useselected,omitempty"`                                  // JSON: string - use selected flag
}

// QualityRequired represents requirements for a quality
// Note: common.Requirement exists with unified structure - future migration could use it
type QualityRequired struct {
	OneOf *QualityRequiredOneOf `json:"oneof,omitempty"` // JSON: object - one-of requirement (e.g., metatype array, quality array, mageenabled)
	AllOf *QualityRequiredAllOf `json:"allof,omitempty"` // JSON: object - all-of requirement (e.g., metatype)
}

// QualityRequiredOneOf represents a one-of requirement
// Note: common.RequirementOneOf exists with similar structure
type QualityRequiredOneOf struct {
	Metatype    []string `json:"metatype,omitempty"`   // JSON: array of strings (e.g., ["Centaur", "Naga", "Pixie", "Sasquatch"])
	Quality     []string `json:"quality,omitempty"`    // JSON: array of strings (e.g., ["Adept", "Aware", "Magician"])
	Power       string   `json:"power,omitempty"`      // JSON: string - power name
	MageEnabled bool     `json:"magenabled,omitempty"` // JSON: boolean - magic enabled flag
}

// QualityForbiddenOneOf represents a one-of forbidden constraint
type QualityForbiddenOneOf struct {
	Quality []string `json:"quality,omitempty"` // JSON: array of strings (e.g., ["Distinctive Style", "Astral Beacon"])
	Bioware []string `json:"bioware,omitempty"` // JSON: array of strings - array of bioware names
	Power   string   `json:"power,omitempty"`   // JSON: string - power name
}

// QualityRequiredAllOf represents an all-of requirement
// Note: common.RequirementAllOf exists with similar structure
type QualityRequiredAllOf struct {
	Metatype string `json:"metatype,omitempty"` // JSON: string - metatype name
}

// QualityForbidden represents forbidden items or qualities
type QualityForbidden struct {
	OneOf *QualityForbiddenOneOf `json:"oneof,omitempty"`
}

// ActionDicePool represents an action dice pool bonus
type ActionDicePool struct {
	Category string `json:"+@category,omitempty"` // JSON: string (e.g., "Matrix") - category for action dice pool
}

// IncludeInLimit represents an include in limit structure
type IncludeInLimit struct {
	Name interface{} `json:"name,omitempty"` // JSON shows: (no instances found in qualities.json for IncludeInLimit.Name)
}

// NaturalWeapon represents a single natural weapon
type NaturalWeapon struct {
	Name     string `json:"name,omitempty"`     // JSON: string - weapon name
	Reach    string `json:"reach,omitempty"`    // JSON: string - reach value
	Damage   string `json:"damage,omitempty"`   // JSON: string - damage value
	AP       string `json:"ap,omitempty"`       // JSON: string - armor penetration
	UseSkill string `json:"useskill,omitempty"` // JSON: string - skill to use
	Accuracy string `json:"accuracy,omitempty"` // JSON: string - accuracy value
	Source   string `json:"source,omitempty"`   // JSON: string - source book
	Page     string `json:"page,omitempty"`     // JSON: string - page number
}

// NaturalWeapons represents the naturalweapons structure
// Can be a single weapon or an array of weapons
type NaturalWeapons struct {
	NaturalWeapon interface{} `json:"naturalweapon,omitempty"` // JSON: object or array of objects - single weapon or array of weapons
}

package v5

// License represents a license name (just a string)
// The actual data is in licenses_data.go


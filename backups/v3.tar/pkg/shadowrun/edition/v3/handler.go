package v3

import (
	"fmt"

	"shadowmaster/internal/domain"
	"shadowmaster/internal/repository"
	edition "shadowmaster/pkg/shadowrun/edition"
)

// SR3Handler implements the EditionHandler interface for Shadowrun 3rd Edition
type SR3Handler struct {
	editionRepo repository.EditionDataRepository
}

// NewSR3Handler creates a new SR3 edition handler
func NewSR3Handler(editionRepo repository.EditionDataRepository) edition.EditionHandler {
	return &SR3Handler{
		editionRepo: editionRepo,
	}
}

// Edition returns the edition identifier
func (h *SR3Handler) Edition() string {
	return "sr3"
}

// PrioritySelection holds character creation priorities for SR3
// Each priority (A-E) can only be used once
// Magic priority: A or B = magical (A: Full Magician, B: Adept/Aspected), C/D/E = mundane
type PrioritySelection struct {
	Magic      string // A-E (A: Full Magician, B: Adept/Aspected, C/D/E: Mundane)
	Metatype   string // A-E
	Attributes string // A-E
	Skills     string // A-E
	Resources  string // A-E
}

// CreateCharacter creates a new SR3 character using priority selection
func (h *SR3Handler) CreateCharacter(name, playerName string, creationData interface{}) (*domain.Character, error) {
	// Validate and convert creation data
	priorities, ok := creationData.(PrioritySelection)
	if !ok {
		// Try to convert from map (for JSON unmarshaling)
		if dataMap, ok := creationData.(map[string]interface{}); ok {
			priorities = PrioritySelection{
				Magic:      getStringFromMap(dataMap, "magic_priority", ""),
				Metatype:   getStringFromMap(dataMap, "metatype_priority", ""),
				Attributes: getStringFromMap(dataMap, "attr_priority", ""),
				Skills:     getStringFromMap(dataMap, "skills_priority", ""),
				Resources:  getStringFromMap(dataMap, "resources_priority", ""),
			}
		} else {
			return nil, fmt.Errorf("invalid creation data type for SR3: expected PrioritySelection, got %T", creationData)
		}
	}

	// Validate that all priorities are assigned
	if priorities.Magic == "" || priorities.Metatype == "" || priorities.Attributes == "" ||
		priorities.Skills == "" || priorities.Resources == "" {
		return nil, fmt.Errorf("all priorities (A-E) must be assigned to each category")
	}

	// Create base character
	character := &domain.Character{
		Name:       name,
		PlayerName: playerName,
		Edition:    "sr3",
	}

	// Initialize SR3 data
	sr3Data := &domain.CharacterSR3{
		MagicPriority:     priorities.Magic,
		MetatypePriority:  priorities.Metatype,
		AttrPriority:      priorities.Attributes,
		SkillsPriority:    priorities.Skills,
		ResourcesPriority: priorities.Resources,

		ActiveSkills:    make(map[string]domain.Skill),
		KnowledgeSkills: make(map[string]domain.Skill),
		LanguageSkills:  make(map[string]domain.Skill),
		Weapons:         []domain.Weapon{},
		Armor:           []domain.Armor{},
		Cyberware:       []domain.Cyberware{},
		Bioware:         []domain.Bioware{},
		Gear:            []domain.Item{},
		Vehicles:        []domain.Vehicle{},
		Spells:          []domain.Spell{},
		Focuses:         []domain.Focus{},
		Spirits:         []domain.Spirit{},
		AdeptPowers:     []domain.AdeptPower{},
		Contacts:        []domain.Contact{},

		Reputation: domain.Reputation{
			StreetCred:      0,
			Notoriety:       0,
			PublicAwareness: 0,
		},

		Karma:      0,
		TotalKarma: 0,
		Nuyen:      getResourcesPriority(priorities.Resources),
	}

	// Apply priority-based character creation
	if err := applyPriorities(sr3Data, priorities); err != nil {
		return nil, err
	}

	// Apply racial special abilities
	applyRacialAbilities(sr3Data)

	// Apply language skills (free native language at rating 6)
	applyLanguageSkills(sr3Data)

	// Apply free contacts (two free level 1 contacts)
	applyFreeContacts(sr3Data)

	// Calculate derived attributes
	sr3Data.Reaction = sr3Data.Quickness + sr3Data.Intelligence
	sr3Data.Essence = 6.0 // Starting essence

	character.SetSR3Data(sr3Data)

	return character, nil
}

// ValidateCharacter validates that a character conforms to SR3 rules
func (h *SR3Handler) ValidateCharacter(character *domain.Character) error {
	if character.Edition != "sr3" {
		return fmt.Errorf("character is not SR3 edition (got: %s)", character.Edition)
	}

	sr3Data, err := character.GetSR3Data()
	if err != nil {
		return fmt.Errorf("invalid SR3 character data: %w", err)
	}

	// Validate attributes are within reasonable bounds (SR3 typically 1-6 natural, higher with augments)
	if sr3Data.Body < 1 || sr3Data.Body > 20 {
		return fmt.Errorf("Body attribute out of range: %d", sr3Data.Body)
	}
	if sr3Data.Quickness < 1 || sr3Data.Quickness > 20 {
		return fmt.Errorf("Quickness attribute out of range: %d", sr3Data.Quickness)
	}
	if sr3Data.Strength < 1 || sr3Data.Strength > 20 {
		return fmt.Errorf("Strength attribute out of range: %d", sr3Data.Strength)
	}
	if sr3Data.Charisma < 1 || sr3Data.Charisma > 20 {
		return fmt.Errorf("Charisma attribute out of range: %d", sr3Data.Charisma)
	}
	if sr3Data.Intelligence < 1 || sr3Data.Intelligence > 20 {
		return fmt.Errorf("Intelligence attribute out of range: %d", sr3Data.Intelligence)
	}
	if sr3Data.Willpower < 1 || sr3Data.Willpower > 20 {
		return fmt.Errorf("Willpower attribute out of range: %d", sr3Data.Willpower)
	}

	// Validate essence is not negative
	if sr3Data.Essence < 0 {
		return fmt.Errorf("Essence cannot be negative: %.2f", sr3Data.Essence)
	}

	// Validate reaction is calculated correctly
	expectedReaction := sr3Data.Quickness + sr3Data.Intelligence
	if sr3Data.Reaction != expectedReaction {
		return fmt.Errorf("Reaction mismatch: expected %d (Quickness + Intelligence), got %d", expectedReaction, sr3Data.Reaction)
	}

	return nil
}

// GetCharacterCreationData returns the metadata needed for SR3 character creation UI
func (h *SR3Handler) GetCharacterCreationData() (*domain.CharacterCreationData, error) {
	if h.editionRepo == nil {
		return nil, fmt.Errorf("edition repository not available")
	}
	return h.editionRepo.GetCharacterCreationData("sr3")
}

// Helper function to extract string from map
func getStringFromMap(m map[string]interface{}, key string, defaultValue string) string {
	if val, ok := m[key]; ok {
		if str, ok := val.(string); ok {
			return str
		}
	}
	return defaultValue
}

// MetatypeModifiers holds attribute modifications for metatypes
type MetatypeModifiers struct {
	Body         int
	Quickness    int
	Strength     int
	Charisma     int
	Intelligence int
	Willpower    int
}

// AttributePoints holds attribute point allocation
type AttributePoints struct {
	Body         int
	Quickness    int
	Strength     int
	Charisma     int
	Intelligence int
	Willpower    int
}

// applyPriorities applies priority system to character
func applyPriorities(char *domain.CharacterSR3, priorities PrioritySelection) error {
	// Apply metatype priority (metatype selection)
	metatype, attrMods, err := getMetatypeFromPriority(priorities.Metatype)
	if err != nil {
		return err
	}
	char.Metatype = metatype
	char.Body += attrMods.Body
	char.Quickness += attrMods.Quickness
	char.Strength += attrMods.Strength
	char.Charisma += attrMods.Charisma
	char.Intelligence += attrMods.Intelligence
	char.Willpower += attrMods.Willpower

	// Apply attribute priority
	attrPoints := getAttributePriority(priorities.Attributes)
	char.Body += attrPoints.Body
	char.Quickness += attrPoints.Quickness
	char.Strength += attrPoints.Strength
	char.Charisma += attrPoints.Charisma
	char.Intelligence += attrPoints.Intelligence
	char.Willpower += attrPoints.Willpower

	// Apply skills priority
	char.SkillsPriority = priorities.Skills

	// Apply magic priority
	// Priority A or B = magical, Priority C/D/E = mundane (Magic Rating 0)
	if priorities.Magic == "A" || priorities.Magic == "B" {
		char.MagicRating = getMagicRatingFromPriority(priorities.Magic)
		char.MagicPriority = priorities.Magic
	} else {
		// Priority C, D, or E = mundane (no magic)
		char.MagicRating = 0
		char.MagicPriority = priorities.Magic
	}

	return nil
}

// getMetatypeFromPriority returns metatype and modifiers based on priority
// Note: This function returns default modifiers. Actual metatype selection should happen
// based on player choice within the allowed metatypes for the priority level.
// This function should be called with the selected metatype name, not the priority.
func getMetatypeFromPriority(priority string) (string, MetatypeModifiers, error) {
	// Simplified: Human is default, higher priorities allow other metatypes
	mods := MetatypeModifiers{} // Human has no modifiers

	switch priority {
	case "A", "B":
		// Allow all metatypes (Human, Elf, Dwarf, Ork, Troll)
		// For now, default to Human - actual selection should be done by player
		return "Human", mods, nil
	case "C":
		// Allow Troll or Elf only
		// For now, default to Elf - actual selection should be done by player
		return "Elf", MetatypeModifiers{Quickness: 1, Charisma: 2}, nil
	case "D":
		// Allow Dwarf or Ork only
		// For now, default to Dwarf - actual selection should be done by player
		return "Dwarf", MetatypeModifiers{Body: 1, Strength: 2, Willpower: 1}, nil
	case "E":
		// Human only
		return "Human", mods, nil
	default:
		return "Human", mods, nil
	}
}

// GetMetatypeModifiers returns attribute modifiers for a given metatype
// Based on the official Shadowrun 3rd Edition Racial Modifications Table
func GetMetatypeModifiers(metatype string) MetatypeModifiers {
	switch metatype {
	case "Human":
		return MetatypeModifiers{} // No modifiers
	case "Dwarf":
		return MetatypeModifiers{
			Body:      1,
			Strength:  2,
			Willpower: 1,
		}
		// Special abilities: Thermographic Vision, Resistance (+2 Body vs disease/toxin)
	case "Elf":
		return MetatypeModifiers{
			Quickness: 1,
			Charisma:  2,
		}
		// Special abilities: Low-light Vision
	case "Ork":
		return MetatypeModifiers{
			Body:         3,
			Strength:     2,
			Charisma:     -1,
			Intelligence: -1,
		}
	case "Troll":
		return MetatypeModifiers{
			Body:         5,
			Quickness:    -1,
			Strength:     4,
			Intelligence: -2,
			Charisma:     -2,
		}
		// Special abilities: Thermographic Vision, +1 Reach for Armed/Unarmed Combat, Dermal Armor (+1 Body)
	default:
		return MetatypeModifiers{} // Default to Human (no modifiers)
	}
}

// getAttributePriority returns attribute points based on priority
func getAttributePriority(priority string) AttributePoints {
	switch priority {
	case "A":
		return AttributePoints{Body: 6, Quickness: 6, Strength: 6, Charisma: 6, Intelligence: 6, Willpower: 6}
	case "B":
		return AttributePoints{Body: 4, Quickness: 4, Strength: 4, Charisma: 4, Intelligence: 4, Willpower: 4}
	case "C":
		return AttributePoints{Body: 3, Quickness: 3, Strength: 3, Charisma: 3, Intelligence: 3, Willpower: 3}
	case "D":
		return AttributePoints{Body: 2, Quickness: 2, Strength: 2, Charisma: 2, Intelligence: 2, Willpower: 2}
	case "E":
		return AttributePoints{Body: 1, Quickness: 1, Strength: 1, Charisma: 1, Intelligence: 1, Willpower: 1}
	default:
		return AttributePoints{}
	}
}

// getMagicRatingFromPriority returns magic rating based on priority
func getMagicRatingFromPriority(priority string) int {
	switch priority {
	case "A":
		return 6
	case "B":
		return 4
	case "C":
		return 2
	default:
		return 0
	}
}

// getResourcesPriority returns starting nuyen based on priority
func getResourcesPriority(priority string) int {
	switch priority {
	case "A":
		return 1000000
	case "B":
		return 400000
	case "C":
		return 90000
	case "D":
		return 20000
	case "E":
		return 5000
	default:
		return 0
	}
}

// applyRacialAbilities applies racial special abilities based on metatype
// This includes adding racial abilities to the RacialAbilities list
// and adding Troll Dermal Armor as inherent cyberware
func applyRacialAbilities(char *domain.CharacterSR3) {
	char.RacialAbilities = []domain.RacialAbility{}

	switch char.Metatype {
	case "Dwarf":
		char.RacialAbilities = append(char.RacialAbilities,
			domain.RacialAbility{
				Name:        "Thermographic Vision",
				Description: "Can see heat signatures",
			},
			domain.RacialAbility{
				Name:        "Resistance",
				Description: "Resistance to disease and toxins",
				Effect:      "+2 Body to any disease or toxin",
			},
		)
	case "Elf":
		char.RacialAbilities = append(char.RacialAbilities,
			domain.RacialAbility{
				Name:        "Low-light Vision",
				Description: "Can see in low-light conditions",
			},
		)
	case "Troll":
		char.RacialAbilities = append(char.RacialAbilities,
			domain.RacialAbility{
				Name:        "Thermographic Vision",
				Description: "Can see heat signatures",
			},
			domain.RacialAbility{
				Name:        "Reach",
				Description: "Increased reach in combat",
				Effect:      "+1 Reach for Armed/Unarmed Combat",
			},
		)
		// Add Troll Dermal Armor as inherent cyberware (no essence cost, no nuyen cost)
		char.Cyberware = append(char.Cyberware,
			domain.Cyberware{
				Name:        "Dermal Armor (Racial)",
				Rating:      1,
				EssenceCost: 0.0, // Inherent - no essence cost
				Cost:        0,   // Inherent - no nuyen cost
				Racial:      true, // Mark as racial cyberware
				Notes:       "Inherent Troll racial trait - +1 Body",
			},
		)
	}
}

// applyLanguageSkills applies language skill rules during character creation
// - Characters get one free native language at rating 6
// - Language skill points = Intelligence * 1.5 (rounded down)
// - Language skills link to Intelligence attribute
func applyLanguageSkills(char *domain.CharacterSR3) {
	// Give one free native language at rating 6 (default to English)
	if len(char.LanguageSkills) == 0 {
		char.LanguageSkills["English"] = domain.Skill{
			Name:   "English",
			Rating: 6,
		}
	}
}

// GetLanguageSkillPoints calculates available language skill points during character creation
// Formula: Intelligence * 1.5 (rounded down)
func GetLanguageSkillPoints(intelligence int) int {
	return int(float64(intelligence) * 1.5)
}

// applyFreeContacts applies free contacts during character creation
// Characters begin with two free level 1 contacts
func applyFreeContacts(char *domain.CharacterSR3) {
	// Give two free level 1 contacts (placeholder names, can be customized)
	if len(char.Contacts) == 0 {
		char.Contacts = []domain.Contact{
			{
				Name:    "Contact 1",
				Type:    "General",
				Level:   1,
				Loyalty: 1,
				Notes:   "Free level 1 contact",
			},
			{
				Name:    "Contact 2",
				Type:    "General",
				Level:   1,
				Loyalty: 1,
				Notes:   "Free level 1 contact",
			},
		}
	}
}

